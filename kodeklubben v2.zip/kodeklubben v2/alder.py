variabel = 4
petter = 'En gutt'
frida = 'En jente'
et_tall = 3
enda_et_tall = variabel + et_tall

navn = input("Skriv navnet ditt: ")
print(navn)
tall = int(input("Skriv et tall: "))
print(2+tall)
